#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/select.h>
#include<time.h>

#define BACKLOG 20
#define BUFF_SIZE 1024
#define MAX_USERNAME_LENGTH 100
#define MAX_PASSWORD_LENGTH 100
#define MAX_CLIENTS 10

typedef struct Account {
char username[MAX_USERNAME_LENGTH]; //username of account
char password[MAX_PASSWORD_LENGTH]; //password of account
int status; //status 0: blocked, 1: active
int num_signin_wrong; // number of wrong login attempt
int is_logged_in; // check if the account is logged in
struct Account* next;
} Account;

Account *head = NULL;
Account *tail = NULL;

int sign_in(char username[MAX_USERNAME_LENGTH], char password[MAX_PASSWORD_LENGTH]);
Account *find_account(char username[MAX_USERNAME_LENGTH]);
void load_accounts();
void save_accounts();
int register_account(char username[MAX_USERNAME_LENGTH], char password[MAX_PASSWORD_LENGTH]);
void sign_out(char username[MAX_USERNAME_LENGTH]);

int main(int argc, char *argv[]) {
    int PORT;
    int listenfd, connfd;
    struct sockaddr_in server, client;
    socklen_t client_len = sizeof(client);
    fd_set master_set, read_set;
    int max_fd, i;
    int client_fds[MAX_CLIENTS];
    char buff[BUFF_SIZE + 1];
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];

    if (argc != 2) {
        printf("Wrong command! ./server PORT\n");
        exit(1);
    } else {
        PORT = atoi(argv[1]);
    }

    load_accounts();

    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("\nError: ");
        exit(1);
    }

    int optval = 1;
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval));

    bzero(&server, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(listenfd, (struct sockaddr*) &server, sizeof(server)) == -1) {
        perror("\nError: ");
        exit(1);
    }

    if (listen(listenfd, BACKLOG) == -1) {
        perror("\nError: ");
        exit(1);
    }

    FD_ZERO(&master_set);
    FD_SET(listenfd, &master_set);
    max_fd = listenfd;

    for (i = 0; i < MAX_CLIENTS; i++) {
        client_fds[i] = -1;
    }

    while (1) {
        read_set = master_set;
        if (select(max_fd + 1, &read_set, NULL, NULL, NULL) == -1) {
            perror("Error in select");
            exit(1);
        }

        for (i = 0; i <= max_fd; i++) {
            if (FD_ISSET(i, &read_set)) {
                if (i == listenfd) {
                    connfd = accept(listenfd, (struct sockaddr*) &client, &client_len);
                    if (connfd == -1) {
                        perror("Error in accept");
                        exit(1);
                    }

                    printf("You got a connection from %s\n", inet_ntoa(client.sin_addr));

                    for (int j = 0; j < MAX_CLIENTS; j++) {
                        if (client_fds[j] == -1) {
                            client_fds[j] = connfd;
                            break;
                        }
                    }

                    FD_SET(connfd, &master_set);
                    if (connfd > max_fd) {
                        max_fd = connfd;
                    }
                } else {
                    int choice;
                    if (recv(i, &choice, sizeof(choice), 0) == -1) {
                        perror("recv() failed");
                        close(i);
                        FD_CLR(i, &master_set);
                        for (int j = 0; j < MAX_CLIENTS; j++) {
                            if (client_fds[j] == i) {
                                client_fds[j] = -1;
                                break;
                            }
                        }
                    } else {
                        if (choice == 1) {//login
                            while (1) {
                                int bytes_received = recv(i, buff, BUFF_SIZE, 0);
                                if (bytes_received < 0) {
                                    perror("\nError: ");
                                    break;
                                } else if (bytes_received == 0) {
                                    //printf("Connection closed.\n");
                                    break;
                                }

                                buff[bytes_received] = '\0';
                                sscanf(buff, "%s %s", username, password);

                                printf("Received username: %s, password: %s\n", username, password);

                                int k = sign_in(username, password);

                                int bytes_sent= send(i, &k, sizeof(k), 0);

                                if (bytes_sent == -1) {
                                    perror("\nError: ");
                                    break;
                                }
                                if(k==1)break;
                            }
                        } else if (choice == 2) {//logout
                                    sign_out(username);
                        }else if (choice == 3) {// signup
                            while (1) {
                                int bytes_received = recv(i, buff, BUFF_SIZE, 0);
                                if (bytes_received < 0) {
                                    perror("\nError: ");
                                    break;
                                } else if (bytes_received == 0) {
                                    //printf("Connection closed.\n");
                                    break;
                                }

                                buff[bytes_received] = '\0';
                                sscanf(buff, "%s %s", username, password);

                                printf("Received username: %s, password: %s\n", username, password);
                                int k=register_account(username,password);
                                int bytes_sent = send(i, &k, sizeof(k), 0);
                                    if (bytes_sent == -1) {
                                        perror("\nError: ");
                                        break;
                                    }
                                    if(k==1)break;
                                }
                        }else if( choice == 4){//received message
                            int bytes_received = recv(i, buff, BUFF_SIZE, 0);
                                if (bytes_received < 0) {
                                    perror("\nError: ");
                                    break;
                                } else if (bytes_received == 0) {
                                    //printf("Connection closed.\n");
                                    break;
                                }

                                buff[bytes_received] = '\0';
                                printf("message received: %s",buff);
                                int k=1;
                                int bytes_sent = send(i, &k, sizeof(k), 0);
                                    if (bytes_sent == -1) {
                                        perror("\nError: ");
                                        break;
                                    }

                        }else if(choice == 5){// received image file and save to rimage.png
                                int file_size;
                                char file_name[50];
                                time_t now = time(NULL);
                                strftime(file_name, sizeof(file_name), "%Y%m%d%H%M%S.png", localtime(&now)); // Add timestamp to the file name
                                FILE *fp;
                                printf("Receiving image file...\n");

                                int bytes_received = recv(i, &file_size, sizeof(file_size), 0);
                                if (bytes_received < 0)
                                    perror("Error: ");
                                else if (bytes_received == 0)
                                    {
                                        //printf("Connection closed.\n");
                                    }

                                printf("File size: %d\n", file_size);

                                if ((fp = fopen(file_name, "wb")) == NULL) {
                                    perror("fopen() failed");
                                    break;
                                }

                                int remaining_size = file_size;
                                while (remaining_size > 0) {
                                    bytes_received = recv(i, buff, BUFF_SIZE, 0);
                                    if (bytes_received < 0)
                                        perror("Error: ");
                                    else if (bytes_received == 0){
                                        //printf("Connection closed.\n");
                                    }

                                    fwrite(buff, 1, bytes_received, fp);
                                    remaining_size -= bytes_received;
                                }

                                fclose(fp);
                                printf("Image file received and saved as '%s'.\n", file_name);
                                break;
			
			}
                    }
                }
            }
        }
    }

    save_accounts();
    close(listenfd);
    return 0;
}

void freeList(Account* head) {
    Account* current = head;
    Account* temp;

    while (current != NULL) {
        temp = current;
        current = current->next;
        free(temp);
    }

    free(head);
}

Account* find_account(char username[MAX_USERNAME_LENGTH]){
	Account* acc = head;
	while (acc != NULL) {
        if(strcmp(acc->username,username) == 0){
			return acc;
		}
			acc = acc->next;
			
    }
    	printf("Cannot find Account.\n");
    	return NULL;
}

// Load account information from the file into the linked list
void load_accounts() {
    FILE* fp = fopen("account.txt", "r");
    if (fp == NULL) {
        printf("Error: cannot open account file.\n");
        return;
    }

    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    int status;
    while (fscanf(fp, "%s %s %d", username, password, &status) == 3) {
        Account* account = malloc(sizeof(Account));
        strcpy(account->username, username);
        strcpy(account->password, password);
        account->status = status;
        account->num_signin_wrong=0;
        account->is_logged_in=0;
        account->next = NULL;
            if (head == NULL) {
                head = account;
            } else {
                tail->next = account;
            }
            tail = account;
            
        //printf("%s %s %d\n",account->username,account->password,account->status);
    }

    fclose(fp);
}

int sign_in(char username[MAX_USERNAME_LENGTH], char password[MAX_PASSWORD_LENGTH]){
    int status;
	
	Account* current = find_account(username);
    if(current != NULL) {
    	//check blocked
		if(current->status==0){
			printf("Account is blocked.\n");
            return 0;
		}else if(current->status==1){

			if(strcmp(current->password,password) == 0){
				printf("Hello %s\n",current->username);
				current->num_signin_wrong=0;
				current->is_logged_in=1;
                return 1;
			}else{
				current->num_signin_wrong=current->num_signin_wrong+1;
				printf("Password is incorrect.\n");
                
				if(current->num_signin_wrong>=3){
					printf("Account is Blocked.\n");
					current->status=0;
					save_accounts();
				}
                return 2;
			}
		}
	}	
}

void save_accounts() {
    FILE* fp = fopen("account.txt", "w");
    if (fp == NULL) {
        printf("Error: cannot open account file.\n");
        return;
    }

    Account* current = head;
    while (current != NULL) {
        fprintf(fp, "%s %s %d\n", current->username, current->password, current->status);
        current = current->next;
    }

    fclose(fp);
}
int register_account(char username[MAX_USERNAME_LENGTH], char password[MAX_PASSWORD_LENGTH]){
	Account* account = head;
	while (account != NULL) {
        if(strcmp(account->username,username) == 0){
        	printf("Account existed.\n");
        	return 0;
		}
			account = account->next;
    }
	if(account==NULL){
		printf("\nSuccessful registration.\n");
	 	Account* account = malloc(sizeof(Account));
        strcpy(account->username, username);
        strcpy(account->password, password);
        account->status = 1;
        account->num_signin_wrong=0;
        account->is_logged_in=0;
    	account->next = NULL;
        if (head == NULL) {
                head = account;
            } else {
                tail->next = account;
            }
            tail = account;
	save_accounts();
    return 1;
	}
}
void sign_out(char username[MAX_USERNAME_LENGTH]){
	Account* current = find_account(username);
	if(current != NULL) {
        if(current->is_logged_in==1){
        		current->is_logged_in=0;
				printf("\nGoodbye %s.\n",current->username);
		}else{
			printf("\nAccount is not sign in.\n");
		}
    }
}