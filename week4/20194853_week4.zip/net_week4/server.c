/*UDP Echo Server*/
#include <stdio.h>          /* These are the usual header files */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>

// Define the maximum length of username and password
#define MAX_USERNAME_LENGTH 50
#define MAX_PASSWORD_LENGTH 50
//#define PORT 5550  /* Port that will be opened */ 
#define BUFF_SIZE 1024

// Define a structure to store account information
typedef struct Account {
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    int status;
    int num_signin_wrong;//know the number of times user entered the wrong password
    int is_logged_in;//=0 not logged_in
    struct Account* next;
}Account;
// Define a linked list to store all accounts6
Account *head=NULL;
Account *tail=NULL;

int sign_in(char username[MAX_USERNAME_LENGTH], char password[MAX_PASSWORD_LENGTH]);// return login result
Account *find_account();//find account in the list
void load_accounts();// Load account information from the file into the linked list
void freeList(Account* head); //free list
void save_accounts();// Save account information from the linked list to the file
void save_password_change(char username[MAX_USERNAME_LENGTH],char password[MAX_PASSWORD_LENGTH]);
int main(int argc, char *argv[])
{
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    int PORT;
	int server_sock; /* file descriptors */
	char buff[BUFF_SIZE];
	int bytes_sent, bytes_received;
	struct sockaddr_in server; /* server's address information */
	struct sockaddr_in client; /* client's address information */
	int sin_size;
    int firstPort = 1;
    int secondPort = 0;
    // Step 0: Get data from command
    if (argc != 2)
    {
        printf("Wrong command!./server PORT\n");
        exit(0);
    }
    else
    {
        PORT = atoi(argv[1]);
    }
    load_accounts();
    
	//Step 1: Construct a UDP socket
	if ((server_sock=socket(AF_INET, SOCK_DGRAM, 0)) == -1 ){  /* calls socket() */
		perror("\nError: ");
		exit(0);
	}
	
	//Step 2: Bind address to socket
	server.sin_family = AF_INET;         
	server.sin_port = htons(PORT);   /* Remember htons() from "Conversions" section? =) */
	server.sin_addr.s_addr = INADDR_ANY;  /* INADDR_ANY puts your IP address automatically */   
	bzero(&(server.sin_zero),8); /* zero the rest of the structure */

  
	if(bind(server_sock,(struct sockaddr*)&server,sizeof(struct sockaddr))==-1){ /* calls bind() */
		perror("\nError: ");
		exit(0);
	}     
	
	//Step 3: Communicate with clients
while(1){
    while(1){
        
        bytes_received = recvfrom(server_sock, username, MAX_USERNAME_LENGTH-1, 0, (struct sockaddr *) &client, &sin_size);
        if(bytes_received < 0){
            perror("Error: ");
            return 0;
        }
        username[bytes_received-1]='\0';
        
        bytes_received = recvfrom(server_sock, password, MAX_PASSWORD_LENGTH-1, 0, (struct sockaddr *) &client, &sin_size);
        if(bytes_received < 0){
            perror("Error: ");
            return 0;
        }
        password[bytes_received-1]='\0';

        //printf("%s %s",username ,password);

        int k=sign_in(username,password);
        bytes_sent = sendto(server_sock, &k, sizeof(k), 0, (struct sockaddr *) &client, sin_size);
        if(bytes_sent < 0){
            perror("Error: ");
            return 0;
        }
        if(k==1)break;
    }

	while(1){
    sin_size = sizeof(struct sockaddr_in);
    bytes_received = recvfrom(server_sock, buff, BUFF_SIZE-1, 0, (struct sockaddr *) &client, &sin_size);
    buff[strcspn(buff, "\n")] = '\0';
    buff[bytes_received]='\0';
    //printf("\n%s %ld  %s\n",buff, strlen(buff),"bye");
    
    if (bytes_received < 0) {
        perror("\nError: ");
    }else if (strcmp(buff, "bye") == 0) {


        char bb[BUFF_SIZE]="Goodbye ";
        strcat(bb,username);
        bytes_sent = sendto(server_sock, bb, strlen(bb), 0, (struct sockaddr *) &client, sin_size);
        if (bytes_sent < 0) {
            perror("\nError: ");					
        }

        printf("sign out\n");
        break;
    }
    else {
        
        char numeric[BUFF_SIZE];
        char alpha[BUFF_SIZE];
        int num_idx = 0;
        int alpha_idx = 0;
        int pwrong=1;
        for (int i = 0; i < bytes_received; i++) {
            if (isdigit(buff[i])) {
                numeric[num_idx++] = buff[i];
            }
            else if (isalpha(buff[i])) {
                alpha[alpha_idx++] = buff[i];
            }else {
                
                pwrong=0;//check if has non-alphanumeric
                break;
            }
            
        }
        if( pwrong==0){
            bytes_sent = sendto(server_sock, "Err1", strlen("Err1"), 0, (struct sockaddr *) &client, sin_size);
                if (bytes_sent < 0) {
                    perror("\nError: ");	
                    	
                }
                printf("password( contains non-alphanumeric characters) \n");
                continue;
        }
        save_password_change(username,buff);
        numeric[num_idx] = '\0';
        alpha[alpha_idx] = '\0';
        printf("[%s:%d]: numeric=%s, alpha=%s.\n", inet_ntoa(client.sin_addr), ntohs(client.sin_port), numeric, alpha);
        bytes_sent = sendto(server_sock, numeric, strlen(numeric), 0, (struct sockaddr *) &client, sin_size);
        if (bytes_sent < 0) {
            perror("\nError: ");					
        }
        bytes_sent = sendto(server_sock, alpha, strlen(alpha), 0, (struct sockaddr *) &client, sin_size);
        if (bytes_sent < 0) {
            perror("\nError: ");					
        }
    }
}
}

	
	close(server_sock);
	return 0;
}


void freeList(Account* head) {
    Account* current = head;
    Account* temp;

    while (current != NULL) {
        temp = current;
        current = current->next;
        free(temp);
    }

    free(head);
}

Account* find_account(char username[MAX_USERNAME_LENGTH]){
	Account* acc = head;
	while (acc != NULL) {
        if(strcmp(acc->username,username) == 0){
			return acc;
		}
			acc = acc->next;
			
    }
    	printf("Cannot find Account.\n");
    	return NULL;
}

// Load account information from the file into the linked list
void load_accounts() {
    FILE* fp = fopen("account.txt", "r");
    if (fp == NULL) {
        printf("Error: cannot open account file.\n");
        return;
    }

    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    int status;
    while (fscanf(fp, "%s %s %d", username, password, &status) == 3) {
        Account* account = malloc(sizeof(Account));
        strcpy(account->username, username);
        strcpy(account->password, password);
        account->status = status;
        account->num_signin_wrong=0;
        account->is_logged_in=0;
        account->next = NULL;
            if (head == NULL) {
                head = account;
            } else {
                tail->next = account;
            }
            tail = account;
            
        //printf("%s %s %d\n",account->username,account->password,account->status);
    }

    fclose(fp);
}

int sign_in(char username[MAX_USERNAME_LENGTH], char password[MAX_PASSWORD_LENGTH]){
    int status;
	
	Account* current = find_account(username);
    if(current != NULL) {
    	//check blocked
		if(current->status==0){
			printf("Account is blocked.\n");
            return 0;
		}else if(current->status==1){

			if(strcmp(current->password,password) == 0){
				printf("Hello %s\n",current->username);
				current->num_signin_wrong=0;
				current->is_logged_in=1;
                return 1;
			}else{
				current->num_signin_wrong=current->num_signin_wrong+1;
				printf("Password is incorrect.\n");
                
				if(current->num_signin_wrong>=3){
					printf("Account is Blocked.\n");
					current->status=0;
					save_accounts();
				}
                return 2;
			}
		}
	}	
}

void save_accounts() {
    FILE* fp = fopen("account.txt", "w");
    if (fp == NULL) {
        printf("Error: cannot open account file.\n");
        return;
    }

    Account* current = head;
    while (current != NULL) {
        fprintf(fp, "%s %s %d\n", current->username, current->password, current->status);
        current = current->next;
    }

    fclose(fp);
}

void save_password_change(char username[MAX_USERNAME_LENGTH],char password[MAX_PASSWORD_LENGTH]){
	Account* account = find_account(username);
	while (account != NULL) {
        if(strcmp(account->username,username) == 0){
        	break;
		}
			account = account->next;
    }
        strcpy(account->password, password);
	save_accounts();
	
}