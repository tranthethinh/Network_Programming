#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include <arpa/inet.h>

int main(int argc, char *argv[]) {
    // Ensure correct usage
    if (argc != 2) {
        printf("Usage: ./resolver domain/IP\n");
        return 1;
    }
    
    // Declare variables
    struct hostent *he; // pointer to hostent struct that will store host information
    struct in_addr **addr_list; // pointer to array of pointers to in_addr structs that will store IP addresses
    char ip[INET_ADDRSTRLEN]; // array of chars to store IP addresses in string form
    
    // Determine if input is an IP address or a domain name
    if (inet_addr(argv[1]) != -1) {
        // If input is IP address, resolve host information
        struct in_addr ipv4addr;
        inet_aton(argv[1], &ipv4addr); // convert IP address from string to binary form and store it in ipv4addr
        he = gethostbyaddr(&ipv4addr, sizeof ipv4addr, AF_INET); // get host information based on binary IP address
        if (he == NULL) {
            printf("Information not found.\n"); // if host information could not be retrieved, print error message and exit
            return 1;
        }
        // Print host information
        printf("Official name: %s\n", he->h_name);
        printf("Alias names:\n");
        for (char **alias = he->h_aliases; *alias != NULL; alias++) { // iterate through array of alias names and print each one
            printf("\t%s\n", *alias);
        }
    } else {
        // If input is domain name, resolve host information
        he = gethostbyname(argv[1]); // get host information based on domain name
        if (he == NULL) {
            printf("Information not found.\n"); // if host information could not be retrieved, print error message and exit
            return 1;
        }
        // Print host information
        printf("Official IP: %s\n", inet_ntop(he->h_addrtype, he->h_addr, ip, sizeof ip)); // convert binary IP address to string and print it
        printf("Alias IPs:\n");
        addr_list = (struct in_addr **)he->h_addr_list; // store array of pointers to IP addresses in addr_list
        for (int i = 0; addr_list[i] != NULL; i++) { // iterate through array of IP addresses and print each one
            printf("\t%s\n", inet_ntoa(*addr_list[i]));
        }
    }
    
    return 0; // exit program
}
