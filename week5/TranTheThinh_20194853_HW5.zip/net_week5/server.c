#include <stdio.h>          /* These are the usual header files */
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include<stdlib.h>


#define PORT 5550   /* Port that will be opened */ 
#define BACKLOG 2   /* Number of allowed connections */
#define BUFF_SIZE 1024

int main()
{
 
	int listen_sock, conn_sock; /* file descriptors */
	char recv_data[BUFF_SIZE];
	int bytes_sent, bytes_received;
	struct sockaddr_in server; /* server's address information */
	struct sockaddr_in client; /* client's address information */
	int sin_size;
	
	//Step 1: Construct a TCP socket to listen connection request
	if ((listen_sock = socket(AF_INET, SOCK_STREAM, 0)) == -1 ){  /* calls socket() */
		perror("\nError: ");
		return 0;
	}
	
	//Step 2: Bind address to socket
	bzero(&server, sizeof(server));
	server.sin_family = AF_INET;         
	server.sin_port = htons(PORT);   /* Remember htons() from "Conversions" section? =) */
	server.sin_addr.s_addr = htonl(INADDR_ANY);  /* INADDR_ANY puts your IP address automatically */   
	if(bind(listen_sock, (struct sockaddr*)&server, sizeof(server))==-1){ /* calls bind() */
		perror("\nError: ");
		return 0;
	}     
	
	//Step 3: Listen request from client
	if(listen(listen_sock, BACKLOG) == -1){  /* calls listen() */
		perror("\nError: ");
		return 0;
	}
	
	//Step 4: Communicate with client
	while(1){
		//accept request
		sin_size = sizeof(struct sockaddr_in);
		if ((conn_sock = accept(listen_sock,( struct sockaddr *)&client, &sin_size)) == -1) 
			perror("\nError: ");
  
		printf("You got a connection from %s\n", inet_ntoa(client.sin_addr) ); /* prints client's IP */
		
		//start conversation
		while(1){
			// receive user choice from client
			int choice;
			if (recv(conn_sock, &choice, sizeof(choice), 0) == -1) {
				   perror("recv() failed");
				   break;
			}

			if( choice==1){
				printf("\nStart receive string and send num and alpha.\n");
				while(1){
				bytes_received = recv(conn_sock, recv_data, BUFF_SIZE-1, 0); //blocking
				if (bytes_received <= 0){
				printf("\nStop receive string.\n");
				break;
			}else if (recv_data[0] == '\n') {
					printf("\nStop receive string.\n");
					break;
				}
				//printf("bytes_received,%d\n",bytes_received);

				recv_data[bytes_received-1] = '\0';
				printf("\nReceive:\n %s ", recv_data);
			
			
			char numeric[BUFF_SIZE];
			char alpha[BUFF_SIZE];
			int num_idx = 0;
			int alpha_idx = 0;
			int pwrong=1;
				for (int i = 0; i < bytes_received-1; i++) {
            if (isdigit(recv_data[i])) {
                numeric[num_idx++] = recv_data[i];
            }
            else if (isalpha(recv_data[i])) {
                alpha[alpha_idx++] = recv_data[i];
            }else {
                
                pwrong=0;//check if has non-alphanumeric
                break;
            }
            
        }
			
			if( pwrong==0){
				bytes_sent = send(conn_sock, "Err1", strlen("Err1"), 0);
					if (bytes_sent <0 ) {
						perror("\nError: ");	
							
					}
					continue;
			}
			numeric[num_idx] = '\0';
			alpha[alpha_idx] = '\0';
			printf("numeric=%s, alpha=%s.\n",  numeric, alpha);
				// send numeric string
				char* combined_message = malloc(strlen(numeric) + strlen(alpha) + 2);
				sprintf(combined_message, "%s\n%s\n", numeric, alpha);

				// Send the combined message over the connection
				send(conn_sock, combined_message, strlen(combined_message), 0);

				// Free the combined message buffer
				free(combined_message);
				}
			}else if(choice==2){
			// 	printf("\nStart receive file");
			// 	bytes_received = recv(conn_sock, recv_data, BUFF_SIZE-1, 0); //blocking
			// 	if (bytes_received <= 0){
			// 	printf("\nStop\n");
			// 	break;
			// }
			// 	recv_data[bytes_received-1] = '\0';
			// 	printf("\nReceive file:\n%s ", recv_data);
			// }

			
				printf("\nFile:\n");
				// Receive the size of the file
				int file_size;
				if (recv(conn_sock, &file_size, sizeof(file_size), 0) == -1) {
					perror("Error receiving file size");
					return 1;
				}

				// Receive the file contents
				int bytes_received = 0;
				while (bytes_received < file_size) {
					int bytes = recv(conn_sock, recv_data, BUFF_SIZE, 0);
					if (bytes == -1) {
						perror("Error receiving file");
						return 1;
					}
					fwrite(recv_data, 1, bytes, stdout);
					bytes_received += bytes;
				}


				printf("\n");
			
			}
			
		}//end conversation
		close(conn_sock);	
	}
	
	close(listen_sock);
	return 0;
}