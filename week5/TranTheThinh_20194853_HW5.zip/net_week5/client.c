#include <stdio.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>

#define SERVER_ADDR "127.0.0.1"
#define SERVER_PORT 5550
#define BUFF_SIZE 8192
void PrintMenu();

int main(){
	char file_name[256];
    FILE *fp;
    size_t bytes_read;
	int client_sock;
	char buff[BUFF_SIZE];
	struct sockaddr_in server_addr; /* server's address information */
	int msg_len, bytes_sent, bytes_received;
	
	//Step 1: Construct socket
	client_sock = socket(AF_INET,SOCK_STREAM,0);
	
	//Step 2: Specify server address
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	server_addr.sin_addr.s_addr = inet_addr(SERVER_ADDR);
	
	//Step 3: Request to connect server
	if(connect(client_sock, (struct sockaddr*)&server_addr, sizeof(struct sockaddr)) < 0){
		printf("\nError!Can not connect to sever! Client exit imediately! ");
		return 0;
	}
		
		int choice =0;
		do{
		PrintMenu();
		scanf("%d", &choice);
		// send user choice to server
		if (send(client_sock, &choice, sizeof(choice), 0) == -1) {
			perror("send() failed");
    }
        switch (choice) {
            case 1:
				int c;
                while ((c = getchar()) != '\n' && c != EOF) {}
				while(1){
					
				//send message
				printf("\nInsert string to send:");
				memset(buff,'\0',(strlen(buff)+1));
				fgets(buff, BUFF_SIZE, stdin);		
				msg_len = strlen(buff);
				//if (msg_len <=1) break;
				
				bytes_sent = send(client_sock, buff, msg_len, 0);
				if (bytes_sent <= 0) {
					printf("\nConnection closed!\n");
					break;
				} else if (buff[0] == '\n') {
					printf("\nStop send String.\n");
					break;
				}
				
				//receive echo reply
				bytes_received = recv(client_sock, buff, BUFF_SIZE-1, 0);
				if(bytes_received <= 0){
					printf("\nError!Cannot receive data from sever!\n");
					break;
				}
				buff[bytes_received] = '\0';
				if( strcmp(buff, "Err1") == 0){
				printf("Incorrect  contains non-alphanumeric characters) \n");
				continue;
				}
				char* message1 = strtok(buff, "\n");
				char* message2 = strtok(NULL, "\n");

				// Print received data
				printf("Received message 1: %s\n", message1);
				printf("Received message 2: %s\n", message2);
		}
                break;
            case 2:
                printf("Enter file name: ");
				scanf("%s", file_name);

				// open file for reading
				if ((fp = fopen(file_name, "rb")) == NULL) {
					perror("fopen() failed");
					break;
				}

				// read file contents into buffer and send to server
				// Get the size of the file
					fseek(fp, 0L, SEEK_END);
					int file_size = ftell(fp);
					rewind(fp);

					// Send the size of the file over the connection
					if (send(client_sock, &file_size, sizeof(file_size), 0) == -1) {
						perror("Error sending file size");
						return 1;
					}

					// Send the file contents over the connection
					while (1) {
						// Read a chunk of data from the file
						size_t bytes_read = fread(buff, 1, BUFF_SIZE, fp);

						// If we've reached the end of the file, break out of the loop
						if (bytes_read == 0) {
							break;
						}

						// Send the chunk of data over the connection
						if (send(client_sock, buff, bytes_read, 0) == -1) {
							perror("Error sending file");
							return 1;
						}
					}


				// close file
				fclose(fp);

					printf("\nFile was sent\n");
					break;
			default:
				break;
			}
	}while (choice >= 1 && choice <= 2);

	//Step 4: Communicate with server			
	
	
	//Step 4: Close socket
	close(client_sock);
	return 0;
}
void PrintMenu(){
	printf("\nMENU\n___________________\n1.Send string\n2.Send file\nYour choice: ");
}